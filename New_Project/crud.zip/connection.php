<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'crudapp';

$conn = new mysqli($servername, $username, $password, $database);
?>    